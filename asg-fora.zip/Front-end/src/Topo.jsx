import React, { useState } from "react";
import "./Topo.css";


function Topo() {
 

  return (
    <div className="container">
      <div className="header">
        <img className="logo" src="/Front-end/public/logo.png" alt="Logo" />
     
          <h1 className="title">Prefeitura Alto Santo da Glória</h1>
          </div>
          </div>
    
  );
}

export default Topo;
